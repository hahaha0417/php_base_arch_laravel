<?php

namespace hahaha\api\function;

/*

use hahaha\api\function\table_account as table_account;
use hahaha\api\function\table_account as function_table_account;

*/

class table_account
{
    use \hahaha\instance;

    // ------------------------------------------------- 
    //  base
    // ------------------------------------------------- 
    // table 取得
    public function get(

    ) 
    {

    }

    // table 新增
    public function add(

    ) 
    {

    }

    // table 更新
    public function update(

    ) 
    {

    }

    // table 刪除
    public function delete(

    ) 
    {

    }

    // table 上傳
    public function upload(

    ) 
    {

    }

    // ------------------------------------------------- 
    //  
    // ------------------------------------------------- 

    // ------------------------------------------------- 
    //  
    // ------------------------------------------------- 

    // ------------------------------------------------- 
    //  
    // ------------------------------------------------- 
    
}