<div class="row">
    <h3>
        {{ $title }}
    </h3>
</div>
