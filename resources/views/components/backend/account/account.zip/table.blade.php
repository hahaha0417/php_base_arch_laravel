<div class="tableFixHead">
    <table class="table table-hover table-striped {{ $class }} " style="height:60%">

    </table>

</div>
